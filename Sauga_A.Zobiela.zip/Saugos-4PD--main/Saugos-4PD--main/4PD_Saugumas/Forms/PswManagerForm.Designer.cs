﻿
namespace _4PD_Saugumas.Forms
{
    partial class PswManagerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.NewPswBtn = new System.Windows.Forms.Button();
            this.UpdatePswBtn = new System.Windows.Forms.Button();
            this.FindPswBtn = new System.Windows.Forms.Button();
            this.DeletePswBtn = new System.Windows.Forms.Button();
            this.newPswGroupBox = new System.Windows.Forms.GroupBox();
            this.generateCreatePswBtn = new System.Windows.Forms.Button();
            this.createPswDataGrid = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SaveNewPswBtn = new System.Windows.Forms.Button();
            this.additionalInfoTxt = new System.Windows.Forms.TextBox();
            this.urlAppTxt = new System.Windows.Forms.TextBox();
            this.pswTxt = new System.Windows.Forms.TextBox();
            this.userNameTxt = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.updatePswGroupBox = new System.Windows.Forms.GroupBox();
            this.UpdateGeneratePswBtn = new System.Windows.Forms.Button();
            this.updatePswDataGrid = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UpdatePsw = new System.Windows.Forms.Button();
            this.updateAdditionalInfoTxt = new System.Windows.Forms.TextBox();
            this.updateURLtxt = new System.Windows.Forms.TextBox();
            this.updatePswTxt = new System.Windows.Forms.TextBox();
            this.updateUsernameTxt = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.deletePswGroupBox = new System.Windows.Forms.GroupBox();
            this.deletePswDataGrid = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DeletePassword = new System.Windows.Forms.Button();
            this.usernameToDeletePswTxt = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.findPswGroupBox = new System.Windows.Forms.GroupBox();
            this.showPsw = new System.Windows.Forms.CheckBox();
            this.ShowAllPswBtn = new System.Windows.Forms.Button();
            this.CopyPswBtn = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FindPswBtn2 = new System.Windows.Forms.Button();
            this.findPswTxt = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.newPswGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.createPswDataGrid)).BeginInit();
            this.updatePswGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.updatePswDataGrid)).BeginInit();
            this.deletePswGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.deletePswDataGrid)).BeginInit();
            this.findPswGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // NewPswBtn
            // 
            this.NewPswBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NewPswBtn.Location = new System.Drawing.Point(12, 12);
            this.NewPswBtn.Name = "NewPswBtn";
            this.NewPswBtn.Size = new System.Drawing.Size(168, 37);
            this.NewPswBtn.TabIndex = 1;
            this.NewPswBtn.Text = "Naujas Slaptažodis";
            this.NewPswBtn.UseVisualStyleBackColor = true;
            this.NewPswBtn.Click += new System.EventHandler(this.NewPswBtn_Click);
            // 
            // UpdatePswBtn
            // 
            this.UpdatePswBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UpdatePswBtn.Location = new System.Drawing.Point(12, 66);
            this.UpdatePswBtn.Name = "UpdatePswBtn";
            this.UpdatePswBtn.Size = new System.Drawing.Size(168, 37);
            this.UpdatePswBtn.TabIndex = 2;
            this.UpdatePswBtn.Text = "Atnaujinti Slaptažodį";
            this.UpdatePswBtn.UseVisualStyleBackColor = true;
            this.UpdatePswBtn.Click += new System.EventHandler(this.UpdatePswBtn_Click);
            // 
            // FindPswBtn
            // 
            this.FindPswBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FindPswBtn.Location = new System.Drawing.Point(12, 120);
            this.FindPswBtn.Name = "FindPswBtn";
            this.FindPswBtn.Size = new System.Drawing.Size(168, 37);
            this.FindPswBtn.TabIndex = 3;
            this.FindPswBtn.Text = "Rasti Slaptažodį";
            this.FindPswBtn.UseVisualStyleBackColor = true;
            this.FindPswBtn.Click += new System.EventHandler(this.FindPswBtn_Click);
            // 
            // DeletePswBtn
            // 
            this.DeletePswBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DeletePswBtn.Location = new System.Drawing.Point(12, 173);
            this.DeletePswBtn.Name = "DeletePswBtn";
            this.DeletePswBtn.Size = new System.Drawing.Size(168, 37);
            this.DeletePswBtn.TabIndex = 4;
            this.DeletePswBtn.Text = "Ištrinti Slaptažodį";
            this.DeletePswBtn.UseVisualStyleBackColor = true;
            this.DeletePswBtn.Click += new System.EventHandler(this.DeletePswBtn_Click);
            // 
            // newPswGroupBox
            // 
            this.newPswGroupBox.Controls.Add(this.generateCreatePswBtn);
            this.newPswGroupBox.Controls.Add(this.createPswDataGrid);
            this.newPswGroupBox.Controls.Add(this.SaveNewPswBtn);
            this.newPswGroupBox.Controls.Add(this.additionalInfoTxt);
            this.newPswGroupBox.Controls.Add(this.urlAppTxt);
            this.newPswGroupBox.Controls.Add(this.pswTxt);
            this.newPswGroupBox.Controls.Add(this.userNameTxt);
            this.newPswGroupBox.Controls.Add(this.label4);
            this.newPswGroupBox.Controls.Add(this.label3);
            this.newPswGroupBox.Controls.Add(this.label2);
            this.newPswGroupBox.Controls.Add(this.label1);
            this.newPswGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.newPswGroupBox.Location = new System.Drawing.Point(186, 12);
            this.newPswGroupBox.Name = "newPswGroupBox";
            this.newPswGroupBox.Size = new System.Drawing.Size(774, 355);
            this.newPswGroupBox.TabIndex = 5;
            this.newPswGroupBox.TabStop = false;
            this.newPswGroupBox.Text = "Sukurti naują slaptažodį";
            // 
            // generateCreatePswBtn
            // 
            this.generateCreatePswBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.generateCreatePswBtn.Location = new System.Drawing.Point(659, 223);
            this.generateCreatePswBtn.Name = "generateCreatePswBtn";
            this.generateCreatePswBtn.Size = new System.Drawing.Size(115, 29);
            this.generateCreatePswBtn.TabIndex = 9;
            this.generateCreatePswBtn.Text = "Generuoti";
            this.generateCreatePswBtn.UseVisualStyleBackColor = true;
            this.generateCreatePswBtn.Click += new System.EventHandler(this.generateCreatePswBtn_Click);
            // 
            // createPswDataGrid
            // 
            this.createPswDataGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.createPswDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.createPswDataGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12});
            this.createPswDataGrid.Location = new System.Drawing.Point(6, 24);
            this.createPswDataGrid.Name = "createPswDataGrid";
            this.createPswDataGrid.ReadOnly = true;
            this.createPswDataGrid.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.createPswDataGrid.Size = new System.Drawing.Size(762, 156);
            this.createPswDataGrid.TabIndex = 8;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.HeaderText = "Vartotojo Vardas";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.HeaderText = "Slaptažodis";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.HeaderText = "URL/Aplikacija";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.HeaderText = "Komentarai";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            // 
            // SaveNewPswBtn
            // 
            this.SaveNewPswBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SaveNewPswBtn.Location = new System.Drawing.Point(332, 320);
            this.SaveNewPswBtn.Name = "SaveNewPswBtn";
            this.SaveNewPswBtn.Size = new System.Drawing.Size(170, 29);
            this.SaveNewPswBtn.TabIndex = 6;
            this.SaveNewPswBtn.Text = "Išsaugoti";
            this.SaveNewPswBtn.UseVisualStyleBackColor = true;
            this.SaveNewPswBtn.Click += new System.EventHandler(this.SaveNewPswBtn_Click);
            // 
            // additionalInfoTxt
            // 
            this.additionalInfoTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.additionalInfoTxt.Location = new System.Drawing.Point(236, 289);
            this.additionalInfoTxt.Name = "additionalInfoTxt";
            this.additionalInfoTxt.Size = new System.Drawing.Size(417, 22);
            this.additionalInfoTxt.TabIndex = 7;
            // 
            // urlAppTxt
            // 
            this.urlAppTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.urlAppTxt.Location = new System.Drawing.Point(236, 258);
            this.urlAppTxt.Name = "urlAppTxt";
            this.urlAppTxt.Size = new System.Drawing.Size(417, 22);
            this.urlAppTxt.TabIndex = 6;
            // 
            // pswTxt
            // 
            this.pswTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pswTxt.Location = new System.Drawing.Point(236, 226);
            this.pswTxt.Name = "pswTxt";
            this.pswTxt.Size = new System.Drawing.Size(417, 22);
            this.pswTxt.TabIndex = 5;
            // 
            // userNameTxt
            // 
            this.userNameTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.userNameTxt.Location = new System.Drawing.Point(236, 194);
            this.userNameTxt.Name = "userNameTxt";
            this.userNameTxt.Size = new System.Drawing.Size(417, 22);
            this.userNameTxt.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(63, 289);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(167, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "Papildoma informacija:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(114, 258);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(116, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "URL/Aplikacija:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(134, 226);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Slaptažodis:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(97, 194);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(133, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Vartotojo Vardas:";
            // 
            // updatePswGroupBox
            // 
            this.updatePswGroupBox.Controls.Add(this.UpdateGeneratePswBtn);
            this.updatePswGroupBox.Controls.Add(this.updatePswDataGrid);
            this.updatePswGroupBox.Controls.Add(this.UpdatePsw);
            this.updatePswGroupBox.Controls.Add(this.updateAdditionalInfoTxt);
            this.updatePswGroupBox.Controls.Add(this.updateURLtxt);
            this.updatePswGroupBox.Controls.Add(this.updatePswTxt);
            this.updatePswGroupBox.Controls.Add(this.updateUsernameTxt);
            this.updatePswGroupBox.Controls.Add(this.label5);
            this.updatePswGroupBox.Controls.Add(this.label6);
            this.updatePswGroupBox.Controls.Add(this.label7);
            this.updatePswGroupBox.Controls.Add(this.label8);
            this.updatePswGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updatePswGroupBox.Location = new System.Drawing.Point(186, 12);
            this.updatePswGroupBox.Name = "updatePswGroupBox";
            this.updatePswGroupBox.Size = new System.Drawing.Size(774, 355);
            this.updatePswGroupBox.TabIndex = 6;
            this.updatePswGroupBox.TabStop = false;
            this.updatePswGroupBox.Text = "Atnaujinti slaptažodį";
            // 
            // UpdateGeneratePswBtn
            // 
            this.UpdateGeneratePswBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UpdateGeneratePswBtn.Location = new System.Drawing.Point(659, 223);
            this.UpdateGeneratePswBtn.Name = "UpdateGeneratePswBtn";
            this.UpdateGeneratePswBtn.Size = new System.Drawing.Size(115, 29);
            this.UpdateGeneratePswBtn.TabIndex = 10;
            this.UpdateGeneratePswBtn.Text = "Generuoti";
            this.UpdateGeneratePswBtn.UseVisualStyleBackColor = true;
            this.UpdateGeneratePswBtn.Click += new System.EventHandler(this.UpdateGeneratePswBtn_Click);
            // 
            // updatePswDataGrid
            // 
            this.updatePswDataGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.updatePswDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.updatePswDataGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8});
            this.updatePswDataGrid.Location = new System.Drawing.Point(6, 24);
            this.updatePswDataGrid.Name = "updatePswDataGrid";
            this.updatePswDataGrid.ReadOnly = true;
            this.updatePswDataGrid.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.updatePswDataGrid.Size = new System.Drawing.Size(762, 149);
            this.updatePswDataGrid.TabIndex = 8;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.HeaderText = "Vartotojo Vardas";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.HeaderText = "Slaptažodis";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.HeaderText = "URL/Aplikacija";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.HeaderText = "Komentarai";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            // 
            // UpdatePsw
            // 
            this.UpdatePsw.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UpdatePsw.Location = new System.Drawing.Point(332, 320);
            this.UpdatePsw.Name = "UpdatePsw";
            this.UpdatePsw.Size = new System.Drawing.Size(170, 29);
            this.UpdatePsw.TabIndex = 6;
            this.UpdatePsw.Text = "Atnaujinti";
            this.UpdatePsw.UseVisualStyleBackColor = true;
            this.UpdatePsw.Click += new System.EventHandler(this.UpdatePsw_Click);
            // 
            // updateAdditionalInfoTxt
            // 
            this.updateAdditionalInfoTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updateAdditionalInfoTxt.Location = new System.Drawing.Point(236, 286);
            this.updateAdditionalInfoTxt.Name = "updateAdditionalInfoTxt";
            this.updateAdditionalInfoTxt.Size = new System.Drawing.Size(417, 22);
            this.updateAdditionalInfoTxt.TabIndex = 7;
            // 
            // updateURLtxt
            // 
            this.updateURLtxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updateURLtxt.Location = new System.Drawing.Point(236, 255);
            this.updateURLtxt.Name = "updateURLtxt";
            this.updateURLtxt.Size = new System.Drawing.Size(417, 22);
            this.updateURLtxt.TabIndex = 6;
            // 
            // updatePswTxt
            // 
            this.updatePswTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updatePswTxt.Location = new System.Drawing.Point(236, 223);
            this.updatePswTxt.Name = "updatePswTxt";
            this.updatePswTxt.Size = new System.Drawing.Size(417, 22);
            this.updatePswTxt.TabIndex = 5;
            // 
            // updateUsernameTxt
            // 
            this.updateUsernameTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updateUsernameTxt.Location = new System.Drawing.Point(236, 191);
            this.updateUsernameTxt.Name = "updateUsernameTxt";
            this.updateUsernameTxt.Size = new System.Drawing.Size(417, 22);
            this.updateUsernameTxt.TabIndex = 4;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(63, 286);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(167, 20);
            this.label5.TabIndex = 3;
            this.label5.Text = "Papildoma informacija:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(114, 255);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(116, 20);
            this.label6.TabIndex = 2;
            this.label6.Text = "URL/Aplikacija:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(134, 223);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(96, 20);
            this.label7.TabIndex = 1;
            this.label7.Text = "Slaptažodis:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(97, 191);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(133, 20);
            this.label8.TabIndex = 0;
            this.label8.Text = "Vartotojo Vardas:";
            // 
            // deletePswGroupBox
            // 
            this.deletePswGroupBox.Controls.Add(this.deletePswDataGrid);
            this.deletePswGroupBox.Controls.Add(this.DeletePassword);
            this.deletePswGroupBox.Controls.Add(this.usernameToDeletePswTxt);
            this.deletePswGroupBox.Controls.Add(this.label12);
            this.deletePswGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deletePswGroupBox.Location = new System.Drawing.Point(186, 12);
            this.deletePswGroupBox.Name = "deletePswGroupBox";
            this.deletePswGroupBox.Size = new System.Drawing.Size(774, 355);
            this.deletePswGroupBox.TabIndex = 7;
            this.deletePswGroupBox.TabStop = false;
            this.deletePswGroupBox.Text = "Ištrinti slaptažodį";
            // 
            // deletePswDataGrid
            // 
            this.deletePswDataGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.deletePswDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.deletePswDataGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4});
            this.deletePswDataGrid.Location = new System.Drawing.Point(6, 24);
            this.deletePswDataGrid.Name = "deletePswDataGrid";
            this.deletePswDataGrid.ReadOnly = true;
            this.deletePswDataGrid.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.deletePswDataGrid.Size = new System.Drawing.Size(762, 164);
            this.deletePswDataGrid.TabIndex = 8;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "Vartotojo Vardas";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "Slaptažodis";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.HeaderText = "URL/Aplikacija";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.HeaderText = "Komentarai";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // DeletePassword
            // 
            this.DeletePassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DeletePassword.Location = new System.Drawing.Point(332, 320);
            this.DeletePassword.Name = "DeletePassword";
            this.DeletePassword.Size = new System.Drawing.Size(170, 29);
            this.DeletePassword.TabIndex = 6;
            this.DeletePassword.Text = "Ištrinti slaptažodį";
            this.DeletePassword.UseVisualStyleBackColor = true;
            this.DeletePassword.Click += new System.EventHandler(this.DeletePassword_Click);
            // 
            // usernameToDeletePswTxt
            // 
            this.usernameToDeletePswTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.usernameToDeletePswTxt.Location = new System.Drawing.Point(246, 258);
            this.usernameToDeletePswTxt.Name = "usernameToDeletePswTxt";
            this.usernameToDeletePswTxt.Size = new System.Drawing.Size(417, 22);
            this.usernameToDeletePswTxt.TabIndex = 4;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(107, 258);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(133, 20);
            this.label12.TabIndex = 0;
            this.label12.Text = "Vartotojo Vardas:";
            // 
            // findPswGroupBox
            // 
            this.findPswGroupBox.Controls.Add(this.showPsw);
            this.findPswGroupBox.Controls.Add(this.ShowAllPswBtn);
            this.findPswGroupBox.Controls.Add(this.CopyPswBtn);
            this.findPswGroupBox.Controls.Add(this.dataGridView1);
            this.findPswGroupBox.Controls.Add(this.FindPswBtn2);
            this.findPswGroupBox.Controls.Add(this.findPswTxt);
            this.findPswGroupBox.Controls.Add(this.label9);
            this.findPswGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.findPswGroupBox.Location = new System.Drawing.Point(186, 12);
            this.findPswGroupBox.Name = "findPswGroupBox";
            this.findPswGroupBox.Size = new System.Drawing.Size(774, 355);
            this.findPswGroupBox.TabIndex = 8;
            this.findPswGroupBox.TabStop = false;
            this.findPswGroupBox.Text = "Rasti Slaptažodį";
            // 
            // showPsw
            // 
            this.showPsw.AutoSize = true;
            this.showPsw.Location = new System.Drawing.Point(6, 195);
            this.showPsw.Name = "showPsw";
            this.showPsw.Size = new System.Drawing.Size(186, 24);
            this.showPsw.TabIndex = 57;
            this.showPsw.Text = "Parodyti slaptažodžius";
            this.showPsw.UseVisualStyleBackColor = true;
            this.showPsw.CheckedChanged += new System.EventHandler(this.showPsw_CheckedChanged);
            // 
            // ShowAllPswBtn
            // 
            this.ShowAllPswBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ShowAllPswBtn.Location = new System.Drawing.Point(364, 195);
            this.ShowAllPswBtn.Name = "ShowAllPswBtn";
            this.ShowAllPswBtn.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ShowAllPswBtn.Size = new System.Drawing.Size(199, 32);
            this.ShowAllPswBtn.TabIndex = 10;
            this.ShowAllPswBtn.Text = "Parodyti visus slaptažodžius";
            this.ShowAllPswBtn.UseVisualStyleBackColor = true;
            this.ShowAllPswBtn.Click += new System.EventHandler(this.ShowAllPswBtn_Click);
            // 
            // CopyPswBtn
            // 
            this.CopyPswBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CopyPswBtn.Location = new System.Drawing.Point(569, 195);
            this.CopyPswBtn.Name = "CopyPswBtn";
            this.CopyPswBtn.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.CopyPswBtn.Size = new System.Drawing.Size(199, 32);
            this.CopyPswBtn.TabIndex = 9;
            this.CopyPswBtn.Text = "Nukopijuoti slaptažodį";
            this.CopyPswBtn.UseVisualStyleBackColor = true;
            this.CopyPswBtn.Click += new System.EventHandler(this.CopyPswBtn_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4});
            this.dataGridView1.Location = new System.Drawing.Point(6, 25);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.dataGridView1.Size = new System.Drawing.Size(762, 164);
            this.dataGridView1.TabIndex = 7;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Vartotojo Vardas";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Slaptažodis";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "URL/Aplikacija";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Komentarai";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            // 
            // FindPswBtn2
            // 
            this.FindPswBtn2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FindPswBtn2.Location = new System.Drawing.Point(332, 320);
            this.FindPswBtn2.Name = "FindPswBtn2";
            this.FindPswBtn2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.FindPswBtn2.Size = new System.Drawing.Size(170, 29);
            this.FindPswBtn2.TabIndex = 6;
            this.FindPswBtn2.Text = "Rasti slaptažodį";
            this.FindPswBtn2.UseVisualStyleBackColor = true;
            this.FindPswBtn2.Click += new System.EventHandler(this.FindPswBtn2_Click);
            // 
            // findPswTxt
            // 
            this.findPswTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.findPswTxt.Location = new System.Drawing.Point(236, 274);
            this.findPswTxt.Name = "findPswTxt";
            this.findPswTxt.Size = new System.Drawing.Size(417, 22);
            this.findPswTxt.TabIndex = 4;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(97, 274);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(133, 20);
            this.label9.TabIndex = 0;
            this.label9.Text = "Vartotojo Vardas:";
            // 
            // PswManagerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(972, 379);
            this.Controls.Add(this.DeletePswBtn);
            this.Controls.Add(this.FindPswBtn);
            this.Controls.Add(this.UpdatePswBtn);
            this.Controls.Add(this.NewPswBtn);
            this.Controls.Add(this.deletePswGroupBox);
            this.Controls.Add(this.updatePswGroupBox);
            this.Controls.Add(this.newPswGroupBox);
            this.Controls.Add(this.findPswGroupBox);
            this.Name = "PswManagerForm";
            this.Text = "PswManagerForm";
            this.newPswGroupBox.ResumeLayout(false);
            this.newPswGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.createPswDataGrid)).EndInit();
            this.updatePswGroupBox.ResumeLayout(false);
            this.updatePswGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.updatePswDataGrid)).EndInit();
            this.deletePswGroupBox.ResumeLayout(false);
            this.deletePswGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.deletePswDataGrid)).EndInit();
            this.findPswGroupBox.ResumeLayout(false);
            this.findPswGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button NewPswBtn;
        private System.Windows.Forms.Button UpdatePswBtn;
        private System.Windows.Forms.Button FindPswBtn;
        private System.Windows.Forms.Button DeletePswBtn;
        private System.Windows.Forms.GroupBox newPswGroupBox;
        private System.Windows.Forms.Button SaveNewPswBtn;
        private System.Windows.Forms.TextBox additionalInfoTxt;
        private System.Windows.Forms.TextBox urlAppTxt;
        private System.Windows.Forms.TextBox pswTxt;
        private System.Windows.Forms.TextBox userNameTxt;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox updatePswGroupBox;
        private System.Windows.Forms.Button UpdatePsw;
        private System.Windows.Forms.TextBox updateAdditionalInfoTxt;
        private System.Windows.Forms.TextBox updateURLtxt;
        private System.Windows.Forms.TextBox updatePswTxt;
        private System.Windows.Forms.TextBox updateUsernameTxt;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox deletePswGroupBox;
        private System.Windows.Forms.GroupBox findPswGroupBox;
        private System.Windows.Forms.Button CopyPswBtn;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button FindPswBtn2;
        private System.Windows.Forms.TextBox findPswTxt;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button DeletePassword;
        private System.Windows.Forms.TextBox usernameToDeletePswTxt;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.CheckBox showPsw;
        private System.Windows.Forms.Button ShowAllPswBtn;
        private System.Windows.Forms.DataGridView updatePswDataGrid;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridView deletePswDataGrid;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridView createPswDataGrid;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.Button generateCreatePswBtn;
        private System.Windows.Forms.Button UpdateGeneratePswBtn;
    }
}