# Saugos-4PD-
Algoritmas informacijos saugumo paskaitai
